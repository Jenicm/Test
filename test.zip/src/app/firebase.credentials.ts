export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyCdgHlJaQqp4RACbA_amQVwwAkrJ4aXg54",
    authDomain: "test-angular-ionic-f4d0e.firebaseapp.com",
    databaseURL: "https://test-angular-ionic-f4d0e.firebaseio.com",
    projectId: "test-angular-ionic-f4d0e",
    storageBucket: "test-angular-ionic-f4d0e.appspot.com",
    messagingSenderId: "662688800809"
}