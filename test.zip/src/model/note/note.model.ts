export interface Note {
    key?: string;
    pregunta: string;
    respuesta1: string;
    respuesta2: string;
    respuesta3: string;
    respuesta4: string;
    correcta: string;
}